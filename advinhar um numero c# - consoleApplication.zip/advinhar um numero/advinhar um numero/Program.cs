﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace advinhar_um_numero
{
    class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            int numeroSecreto = random.Next(1, 101); 
            int tentativa = 0;
            int palpites = 0;

            Console.WriteLine("Tente adivinhar o número entre 1 e 100!");

            while (tentativa != numeroSecreto)
            {
                Console.Write("Digite seu palpite: ");
                string entrada = Console.ReadLine();

                if (!int.TryParse(entrada, out tentativa))
                {
                    Console.WriteLine("Por favor, digite um número válido.");
                    continue;
                }

                palpites++;

                if (tentativa < numeroSecreto)
                {
                    Console.WriteLine("Muito baixo! Tente novamente.");
                }
                else if (tentativa > numeroSecreto)
                {
                    Console.WriteLine("Muito alto! Tente novamente.");
                }
                else
                {
                    Console.WriteLine("Parabéns! Você acertou.");
                }
            }
            Console.ReadKey();
        }
        
    }
}
